//Virtual Memory
//Saturday 16, 2019

#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

#define PAGES 256
#define TOTAL_TLB 16
#define PAGE_TABLE 255
#define SIZE_OF_PAGE 256
#define BITS 8
#define PHYSICAL_MEMORY PAGES * SIZE_OF_PAGE

#define BUFFER 10
struct virutalAddress {
	unsigned char logical;
	unsigned char physical;
};

struct virutalAddress tlb[TOTAL_TLB];

int index = 0;

int pagetable[PAGES];
signed char main_memory[PHYSICAL_MEMORY];
signed char *backingStore;

int max(int val1, int val2){
	if (val1 > val2){
		return val1;
		return val2;
	}
}

int search(unsigned char logical_page) {
	for(int i=max((index - TOTAL_TLB),0); i < index; i++){
		struct virutalAddress *entry = &tlb[i % TOTAL_TLB];
		if (entry -> logical == logical_page){
			return entry -> physical;
		}
	}
	return -1;
}

void adding(unsigned char logical, unsigned char physical) {
	struct virutalAddress *entry = &tlb[index % TOTAL_TLB];
	index++;
	entry->logical = logical;
	entry->physical = physical;
}

#define ARGC_ERROR 1

int main(int argc, const char *argv[]){
	if (argc != 3) {
	fprintf(stderr, "Usage: ./virt.mem filename\n");
	exit(ARGC_ERROR);
	}

	const char *filename = argv[1];
	int backing_fd = open(filename, O_RDONLY);
	backingStore = mmap(0, PHYSICAL_MEMORY, PROT_READ, MAP_PRIVATE, backing_fd, 0);

	const char *inputFile = argv[2];
	FILE *fp = fopen(inputFile, "r");


	for (int i = 0; i < PAGES; i++) {
		pagetable[i] = -1;
	}

	char buffer[BUFFER];

	int total = 0;
	int tlbHit = 0;
	int pageFault = 0;

	unsigned char unallocated = 0;
	while (fgets(buffer, BUFFER, fp) != NULL) {
		total++;
		int logicalAdd = atoi(buffer);
		int offset = logicalAdd & 255;
		int logicalPage = (logicalAdd >> BITS) & PAGE_TABLE;
		int physicalPage = search(logicalPage);

		if(physicalPage != -1){
			tlbHit++;
		}
		else{
			physicalPage = pagetable[logicalPage];
			if(physicalPage == -1){
				pageFault++;
				physicalPage = unallocated;
				unallocated++;
				memcpy(main_memory + physicalPage * SIZE_OF_PAGE, backingStore + logicalPage * SIZE_OF_PAGE, SIZE_OF_PAGE);
				pagetable[logicalPage] = physicalPage;
			}
			adding(logicalPage, physicalPage);
		}
		int physicalAdd = (physicalPage << BITS) | offset;
		signed char value = main_memory[physicalPage * SIZE_OF_PAGE + offset];
		printf("Virtual address: %d Physical address: %d Value:%d\n",logicalAdd, physicalAdd,value );
	}

	printf("Total translated = %d\n", total);

	double pageFaultRate = 0.0;
	pageFaultRate = (double) pageFault / 1000 * 100;

	double tlbHitRate = 0.0;
	tlbHitRate = (double) tlbHit / 1000 * 100;

	printf("Total page faults = %d\n", pageFault);
	printf("The rate for page fault = %.3f\n", pageFaultRate);
	printf("TLB Hit = %d\n", tlbHit);
	printf("The rate for TLB hit rate = %.3f\n", tlbHitRate);

	return 0;
}
